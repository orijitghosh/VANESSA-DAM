library(testthat)
library(damr)

test_check("damr")
